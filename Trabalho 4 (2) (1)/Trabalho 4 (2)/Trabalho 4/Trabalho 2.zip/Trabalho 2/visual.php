<div id="representacao">
    <canvas class="atomos" id="canvas_esquerda"></canvas>
    <div class= "ceta" id='divisao'><h1>→</h1></div>
    <canvas class="atomos" id="canvas_direita"></canvas>
</div>
</main>
    <footer></footer>
    <script src="script.js"></script>
</body>
</html>