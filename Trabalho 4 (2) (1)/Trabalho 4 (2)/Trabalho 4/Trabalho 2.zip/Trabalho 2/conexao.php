<?php
// conexao com o banco de dados
$conexao = mysqli_connect('localhost', 'root', '', 'livros');
?>